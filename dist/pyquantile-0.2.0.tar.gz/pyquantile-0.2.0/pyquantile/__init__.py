from _pyquantile import QuantileEstimator

__all__ = ['QuantileEstimator']